create
    definer = anam@`192.168.%` procedure add_ticket(IN p_categoryId int, IN p_equipmentLocationId int,
                                                    IN p_equipmentModelId int, IN p_equipmentSerialId int,
                                                    IN p_situation varchar(250), IN p_comment varchar(2000),
                                                    IN p_userid int, OUT p_ticketHistoyID int, OUT p_result tinyint,
                                                    OUT p_message varchar(250))
BEGIN 
    
    INSERT INTO Tickets 
    VALUES (0,p_categoryId,p_equipmentLocationId,p_equipmentModelId,p_equipmentSerialId,NOW(), NULL,NOW(),NULL,p_situation, 4);    
    set @ticket = LAST_INSERT_ID();
	INSERT INTO TicketsHistory     
	VALUES(0, @ticket ,p_comment, NOW(),0,NULL,4,p_userid);        
    set @tiketHistory = (select ticketsHistoryId from ticketshistory where ticketId = @ticket order by ticketsHistoryId desc limit 1);   
    
    
    IF(@ticket > 0 AND @tiketHistory > 0) THEN
		SET p_ticketHistoyID = @tiketHistory;
		SET p_result = 1;
        SET p_message = '¡Se ha creado un nuevo ticket!';
    ELSE
		SET p_ticketHistoyID = @tiketHistory;
		SET p_result = 0;
        SET p_message = '¡El ticket no se pudo crear!';
    END IF;
END;

