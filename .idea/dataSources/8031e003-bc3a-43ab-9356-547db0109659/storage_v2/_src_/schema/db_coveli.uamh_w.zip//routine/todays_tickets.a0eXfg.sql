create
    definer = anam@`192.168.%` procedure todays_tickets()
BEGIN
	SELECT COUNT(*) as count FROM tickets
    WHERE DATE(openDate) = CURDATE();
END;

