create
    definer = anam@`192.168.%` procedure get_graph(IN searchedPeriod varchar(20))
BEGIN
	SELECT period, date, priorityId, count, statusId FROM (
    SELECT 'Monthly' as search, MONTH(openDate) as period, DATE(openDate) as date, t.priorityId, count(t.statusId) as count, t.statusId
        FROM tickets t
		WHERE MONTH(openDate) = MONTH(NOW())
        GROUP BY t.statusId, t.priorityId
	UNION ALL        
	SELECT 'Weekly' as search, DAYOFWEEK(openDate) as period, DATE(openDate) as date, t.priorityId, COUNT(t.priorityId) as count, t.statusId
        FROM tickets t
		WHERE WEEK(openDate) = WEEK(NOW())
        GROUP BY t.statusId, t.priorityId)
	AS Graph WHERE search = searchedPeriod;			
END;

