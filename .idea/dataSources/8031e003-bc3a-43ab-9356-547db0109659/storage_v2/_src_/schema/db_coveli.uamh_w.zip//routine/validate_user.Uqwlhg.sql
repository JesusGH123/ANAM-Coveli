create
    definer = anam@`192.168.%` procedure validate_user(INOUT p_email varchar(150), IN p_password varchar(500),
                                                       OUT p_roleid int, OUT p_fullname varchar(150), OUT p_userid int,
                                                       OUT p_result tinyint, OUT p_message varchar(250))
BEGIN
	
	SELECT count(*) INTO @count	FROM Users U  WHERE U.email = p_email AND U.PASSWORD = p_password;
    IF @count = 0 THEN
		SET p_result=0;
        SET p_message='¡Usuario no encontrado!';
    ELSE
		SELECT count(*) INTO @count	FROM Users U  WHERE U.email = p_email AND U.PASSWORD = p_password AND U.statusid = 2;
        IF @count = 1 THEN        
			SET p_result=0;
			SET p_message='¡Usuario se encuentra desactivado!';
		ELSE 
			SELECT count(*) INTO @count	FROM Users U  WHERE U.email = p_email AND U.PASSWORD = p_password AND U.statusid = 3;
			IF @count = 1 then
				SET p_result=0;
			SET p_message='¡Usuario no encontrado!';
            ELSE
				SELECT U.userid,U.email,U.roleid, U.fullname INTO p_userid,p_email,p_roleid,p_fullname 
				FROM Users U  
				WHERE U.email = p_email 
				AND U.PASSWORD = p_password
				AND U.statusid = 1;
				
				SET p_result=1;
				SET p_message='¡Usuario encontrado!';
            END IF;
		END IF;    		
    END IF;
END;

