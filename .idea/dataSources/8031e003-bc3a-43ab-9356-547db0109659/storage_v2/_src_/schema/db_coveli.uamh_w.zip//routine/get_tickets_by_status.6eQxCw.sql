create
    definer = anam@`192.168.%` procedure get_tickets_by_status(IN p_status varchar(128), IN p_userid int)
BEGIN
	SET lc_time_names = 'es_MX';
	set @roleid = (select case when count(roleid) > 0 THEN roleid ELSE 0 END as roleid  from users where userid = p_userid);
	
    SELECT DISTINCT t.ticketId, t.categoryId, c.category, t.equipmentLocationId, eql.equipmentLocation,  
	t.equipmentModelId, eqm.equipmentModel, t.equipmentSerialId, eqs.equipmentSerial,
	DATE_FORMAT(t.modificationDate, "%M %d, %Y %r") modificationDate, t.onTime, DATE_FORMAT(t.openDate, "%M %d, %Y %r") openDate,t.priorityId, CASE WHEN t.priorityId IS NULL THEN '' ELSE p.priority END priority, t.situation,t.statusid,s.status,
    (select distinct cu.userID as client from ticketsHistory thh inner join users cu on (thh.userid = cu.userid) where thh.ticketid = th.ticketid and  thh.statusId =  4) AS clientId,
    (select distinct cu.fullName as client from ticketsHistory thh inner join users cu on (thh.userid = cu.userid) where thh.ticketid = th.ticketid and  thh.statusId =  4) AS client,
    (select distinct thh.technicalId as technicalId from ticketsHistory thh inner join users tu on (thh.technicalId = tu.userid) where thh.ticketid = th.ticketid and  thh.statusId =  5 order by thh.ticketshistoryid asc limit 1) as technicalId,
    (select distinct tu.fullName as technical from ticketsHistory thh inner join users tu on (thh.technicalId = tu.userid) where thh.ticketid = th.ticketid and  thh.statusId =  5 order by thh.ticketshistoryid asc limit 1) as technical,t.situation
	FROM tickets t
	INNER JOIN categories c ON (t.categoryId = c.categoryId)
	INNER JOIN equipmentlocations eql on (t.equipmentLocationId = eql.equipmentLocationId)
	INNER JOIN equipmentmodels eqm on (t.equipmentModelId = eqm.equipmentModelId)
	INNER JOIN equipmentserials eqs on (t.equipmentSerialId = eqs.equipmentSerialId)
	INNER JOIN status s ON (t.statusId = s.statusId)
	INNER JOIN priorities p on (t.priorityId = p.priorityId OR t.priorityId IS NULL)    
    INNER JOIN ticketsHistory th ON (t.ticketId = th.ticketId)    
    WHERE ((@roleid = 3 AND th.technicalid = p_userid) OR (p_userid = 0 OR th.userid = p_userid))    
    and FIND_IN_SET(t.statusid, p_status)
    order by t.priorityId asc , t.ticketId asc;	
END;

