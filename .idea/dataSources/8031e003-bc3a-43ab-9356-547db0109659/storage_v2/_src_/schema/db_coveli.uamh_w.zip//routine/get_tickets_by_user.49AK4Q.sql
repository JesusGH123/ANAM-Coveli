create
    definer = anam@`192.168.%` procedure get_tickets_by_user(IN p_userId int)
BEGIN

	SET lc_time_names = 'es_MX';
	SET @userRole = (SELECT roleId FROM users WHERE userId = p_userId);

	IF @userRole = 3 THEN
        SELECT t.ticketId, situation, fullName, currentDate, priority, p.priorityId, s.statusId
        FROM tickets t 
        LEFT JOIN status s ON (s.statusId = t.statusId)
		LEFT JOIN ticketshistory th ON (th.ticketId = t.ticketId AND th.currentDate = t.modificationDate)
        LEFT JOIN users u ON (u.userId = th.userId)
        LEFT JOIN priorities p ON (p.priorityId = t.priorityId)
        WHERE t.ticketId 
        IN (SELECT distinct(t.ticketId)
        FROM tickets t
		LEFT JOIN ticketshistory th ON (t.ticketId = th.ticketId)
		WHERE th.statusId = t.statusId AND technicalId = p_userId)
        ORDER BY priorityId ASC;
    END IF;
END;

