create
    definer = anam@`192.168.%` procedure out_of_time_tickets()
BEGIN 
	SELECT COUNT(ticketId) as count FROM tickets
    WHERE onTime = 0;
END;

