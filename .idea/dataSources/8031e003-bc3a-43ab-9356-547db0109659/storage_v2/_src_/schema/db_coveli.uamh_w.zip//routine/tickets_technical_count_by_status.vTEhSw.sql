create
    definer = anam@`192.168.%` procedure tickets_technical_count_by_status(IN p_userId int, IN p_status int)
BEGIN
	IF p_status <> 9 THEN -- Without attendance
		SELECT COUNT(DISTINCT(t.ticketId)) AS count FROM ticketshistory th
		INNER JOIN tickets t ON (t.ticketId = th.ticketId)
		WHERE th.technicalID = p_userId AND th.statusId = p_status AND t.statusId <> 9;
	ELSE IF p_status = 9 THEN -- Paused
		SELECT COUNT(DISTINCT(t.ticketId)) AS count FROM ticketshistory th
		INNER JOIN tickets t ON (t.ticketId = th.ticketId)
		WHERE th.technicalID = 1 AND th.statusId = 9 AND t.statusId = 9;
    END IF;
	END IF;
END;

