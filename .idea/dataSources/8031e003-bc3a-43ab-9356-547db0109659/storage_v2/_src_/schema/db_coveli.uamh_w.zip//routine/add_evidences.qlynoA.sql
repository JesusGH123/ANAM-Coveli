create
    definer = anam@`192.168.%` procedure add_evidences(IN p_ticketHistoryId int, IN p_evidencia longtext)
BEGIN
INSERT INTO evidences
VALUES(p_ticketHistoryId,p_evidencia);
END;

