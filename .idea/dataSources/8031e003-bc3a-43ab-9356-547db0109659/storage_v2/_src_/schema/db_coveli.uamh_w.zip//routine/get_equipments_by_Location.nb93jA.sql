create
    definer = anam@`192.168.%` procedure get_equipments_by_Location(IN p_equipmentLocationId int)
BEGIN
	select distinct p_equipmentLocationId equipmentLocationId, eqml.equipmentModelId, eqm.equipmentModel
	from equipmentmodelsbyequipmentlocatios eqml
	inner join equipmentmodels eqm on (eqml.equipmentModelId = eqm.equipmentModelId)
	where eqml.equipmentLocationId = p_equipmentLocationId
	order by eqm.equipmentModel;    
END;

