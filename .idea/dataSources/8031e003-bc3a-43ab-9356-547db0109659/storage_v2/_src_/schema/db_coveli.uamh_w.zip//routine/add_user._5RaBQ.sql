create
    definer = anam@`192.168.%` procedure add_user(IN p_fullname varchar(500), IN p_email varchar(250),
                                                  IN p_password varchar(500), IN p_roleid int, OUT p_result tinyint,
                                                  OUT p_message varchar(500))
BEGIN	
	set p_result = 1;
    set p_message = '';    
    SET @count = (SELECT count(*) FROM users where email=p_email and statusid = 1);    
    
    IF @count = 1 THEN      
     set p_result = 0;
     set p_message = CONCAT('El usuario ' , p_email , ', ya existe!');
	ELSE
		INSERT INTO USERS VALUES (0,p_fullname, p_email, p_password, 1, p_roleid, null, null);
        SET @count = (SELECT count(*) FROM users where email=p_email and statusid = 1);    
        IF @count = 0 THEN
			set p_result = 0;
			set p_message = CONCAT('¡No se guardó el usario!');
		ELSE
			set p_result = 1;
			set p_message = CONCAT('¡Usuario guardado correctamente!');
        END IF;        
	END IF;    
END;

