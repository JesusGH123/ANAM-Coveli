create
    definer = anam@`192.168.%` procedure validate_forgot_token(IN token varchar(128))
BEGIN
	SET @expiration = 0;
    
    SELECT CASE WHEN (resetPasswordExpires - NOW()) <= 0 THEN @expiration = 1 END
    FROM users
	WHERE resetPasswordToken = token;

	SELECT @expiration;
    
	IF(@expiration) THEN
		UPDATE users
        SET resetPasswordToken = NULL,
		users.resetPasswordExpires = NULL
		WHERE resetPasswordToken = token;
        SELECT 0 as keyExists;
    ELSE
        SELECT
		EXISTS(
		SELECT userId FROM users WHERE resetPasswordToken = token
		) as keyExists;
	END IF;
END;

