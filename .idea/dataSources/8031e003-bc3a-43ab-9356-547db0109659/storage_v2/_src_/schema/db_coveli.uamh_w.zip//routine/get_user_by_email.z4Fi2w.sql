create
    definer = anam@`192.168.%` procedure get_user_by_email(IN p_email varchar(256))
BEGIN
	SELECT * FROM Users WHERE email = p_email;
END;

