create
    definer = anam@`192.168.%` procedure get_ticketHistory(IN p_ticketId int)
BEGIN

SELECT th.comment,  DATE_FORMAT(th.currentDate, "%M %d, %Y %r") currentDate,
CONCAT(FLOOR(th.elapsedTime/3600), 'h ',
FLOOR(((th.elapsedTime)%3600)/60), "m ",
FLOOR((((th.elapsedTime)%3600)%60)), 's') elapsedTime,
tu.fullName technicalFullName, s.status,
u.fullName userFullName
from ticketshistory th
LEFT JOIN users tu ON (th.technicalID = tu.userId and th.statusId = 5)
INNER JOIN status s ON (th.statusid = s.statusid)
INNER JOIN users u on (th.userId = u.userId)
WHERE th.ticketId = p_ticketId;

END;

