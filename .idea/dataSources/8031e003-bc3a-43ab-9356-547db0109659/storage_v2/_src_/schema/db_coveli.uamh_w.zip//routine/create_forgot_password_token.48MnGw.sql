create
    definer = anam@`192.168.%` procedure create_forgot_password_token(IN userEmail varchar(128), IN token varchar(128))
BEGIN
	UPDATE users
    SET 
		resetPasswordToken = token,
        resetPasswordExpires = date_add(NOW(),interval 60 minute)
	WHERE
		email = userEmail;
END;

