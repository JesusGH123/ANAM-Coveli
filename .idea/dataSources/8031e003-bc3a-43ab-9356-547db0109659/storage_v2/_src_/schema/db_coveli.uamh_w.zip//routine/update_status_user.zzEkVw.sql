create
    definer = anam@`192.168.%` procedure update_status_user(IN p_userid int, IN p_statusid int, OUT p_result tinyint,
                                                            OUT p_message varchar(500))
BEGIN
	set p_result = 1;
    set p_message = '';    
    SET @count = (SELECT count(*) FROM users U where U.userid = p_userid);
    
    IF @count = 0 THEN
		set p_result = 0;
		set p_message = '¡El usuario que intenta no existe!';    
	ELSE    
			UPDATE Users U
			SET U.statusid = p_statusid
			WHERE U.userid = p_userid;    
            
            set p_result = 1;
            
            IF p_statusid = 1 then				
				set p_message = '¡El usuario ha sido activado!';    
            else if p_statusid = 2 then
				set p_message = '¡El usuario ha sido desactivado!'; 			
			else if p_statusid = 3 then
				set p_message = '¡El usuario ha sido eliminado!'; 			
			END IF;
			END IF;
            END IF;
    END IF;
END;

