create
    definer = anam@`192.168.%` procedure get_all_tickets_count_by_status(IN p_statusid varchar(250), IN p_userid int)
BEGIN

	set @roleid = (select case when count(roleid) > 0 THEN roleid ELSE 0 END as roleid  from users where userid = p_userid);

	SELECT COUNT(DISTINCT t.ticketId) as count
	FROM tickets t
	INNER JOIN categories c ON (t.categoryId = c.categoryId)
	INNER JOIN equipmentlocations eql on (t.equipmentLocationId = eql.equipmentLocationId)
	INNER JOIN equipmentmodels eqm on (t.equipmentModelId = eqm.equipmentModelId)
	INNER JOIN equipmentserials eqs on (t.equipmentSerialId = eqs.equipmentSerialId)
	INNER JOIN status s ON (t.statusId = s.statusId)
	INNER JOIN priorities p on (t.priorityId = p.priorityId OR t.priorityId IS NULL)    
    INNER JOIN ticketsHistory th ON (t.ticketId = th.ticketId)    
    WHERE ((@roleid = 3 AND th.technicalid = p_userid) OR (p_userid = 0 OR th.userid = p_userid))    
    and FIND_IN_SET(t.statusid, p_statusid)
    order by t.priorityId asc , t.ticketId asc;	
    
	
END;

