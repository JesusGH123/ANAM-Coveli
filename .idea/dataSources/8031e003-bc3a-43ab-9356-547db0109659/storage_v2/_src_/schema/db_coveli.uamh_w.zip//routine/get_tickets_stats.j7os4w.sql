create
    definer = anam@`192.168.%` procedure get_tickets_stats()
BEGIN
	select
    CASE WHEN
    ( SELECT CASE WHEN MONTH(t.openDate) = MONTH(NOW()) THEN 
		CONCAT(
		FLOOR((sum(elapsedTime)/count(*))/3600),"h ",
        FLOOR(((sum(elapsedTime)/count(*))%3600)/60), "m")
        ELSE
        '0h 0m'
        END	as time
		FROM ticketsHistory th
		INNER JOIN tickets t
		ON t.ticketId = th.ticketId
		WHERE th.statusId = 9 
		AND t.priorityId = p.priorityId
		GROUP BY t.priorityId
	) 
    IS NULL THEN '0h 0m' ELSE
    ( SELECT CASE WHEN MONTH(t.openDate) = MONTH(NOW()) THEN 
		CONCAT(
		FLOOR((sum(elapsedTime)/count(*))/3600),"h ",
        FLOOR(((sum(elapsedTime)/count(*))%3600)/60), "m")
        ELSE
        '0h 0m'
        END	as time
		FROM ticketsHistory th
		INNER JOIN tickets t
		ON t.ticketId = th.ticketId
		WHERE th.statusId = 9 
		AND t.priorityId = p.priorityId
		GROUP BY t.priorityId
	) 
END AS time,
p.priorityId
from priorities p;
END;

