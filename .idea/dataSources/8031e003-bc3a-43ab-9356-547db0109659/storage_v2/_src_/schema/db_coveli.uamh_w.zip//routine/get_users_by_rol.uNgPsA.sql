create
    definer = anam@`192.168.%` procedure get_users_by_rol(IN p_roleId int)
BEGIN
	SELECT U.userId, U.fullName, U.email, U.statusId, S.status, U.roleId, R.role  FROM USERS U 
	INNER JOIN STATUS S ON (U.STATUSID = S.STATUSID)
	INNER JOIN ROLES R ON (U.ROLEID = R.ROLEID)
    WHERE U.roleId = p_roleId;
END;

