create
    definer = anam@`192.168.%` procedure get_all_tickets_count()
BEGIN
	SELECT COUNT(*) as count FROM tickets;
END;

