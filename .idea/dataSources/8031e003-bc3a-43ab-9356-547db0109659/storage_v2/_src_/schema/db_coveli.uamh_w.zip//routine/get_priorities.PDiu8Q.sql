create
    definer = anam@`192.168.%` procedure get_priorities()
BEGIN
	select priorityId, priority from priorities;
END;

