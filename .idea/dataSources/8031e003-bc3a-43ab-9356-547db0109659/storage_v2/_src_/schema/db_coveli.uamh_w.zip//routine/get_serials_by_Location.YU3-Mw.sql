create
    definer = anam@`192.168.%` procedure get_serials_by_Location(IN p_equipmentLocationId int, IN p_equipmentModelId int)
BEGIN
	select eqs.equipmentSerialId, eqs.equipmentSerial
	from equipmentmodelsbyequipmentlocatios eqml		
	inner join equipmentserials eqs on (eqml.equipmentSerialId = eqs.equipmentSerialId)
    where eqml.equipmentLocationId = p_equipmentLocationId and eqml.equipmentModelId = p_equipmentModelId
	order by eqs.equipmentSerial;    
END;

