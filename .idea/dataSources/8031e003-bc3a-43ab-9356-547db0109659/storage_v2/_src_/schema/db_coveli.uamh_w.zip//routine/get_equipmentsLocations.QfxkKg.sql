create
    definer = anam@`192.168.%` procedure get_equipmentsLocations()
BEGIN
 select equipmentlocationId, equipmentlocation from equipmentLocations;
END;

