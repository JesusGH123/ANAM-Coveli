create
    definer = anam@`192.168.%` procedure update_user_password(IN resetToken varchar(250), IN newPassword varchar(300))
BEGIN
	UPDATE users
    SET
		password = newPassword
	WHERE
		resetPasswordToken = resetToken;
	
	UPDATE users
        SET resetPasswordToken = NULL,
		users.resetPasswordExpires = NULL
		WHERE resetPasswordToken = token;
END;

