create
    definer = anam@`192.168.%` procedure get_accesible_views(IN p_roleId int)
BEGIN
	SELECT path FROM viewsbyrole WHERE roleId = p_roleId;
END;

