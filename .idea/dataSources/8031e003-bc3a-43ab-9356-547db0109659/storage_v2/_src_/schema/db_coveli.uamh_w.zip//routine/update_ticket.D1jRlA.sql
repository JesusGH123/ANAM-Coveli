create
    definer = anam@`192.168.%` procedure update_ticket(IN p_userId int, IN p_ticketId int, IN p_statusId int,
                                                       IN p_comment varchar(2000), IN p_technicalId int,
                                                       IN p_priorityId int, OUT p_ticketHistoyID int,
                                                       OUT p_result tinyint, OUT p_message varchar(250))
BEGIN

	set @tiketHistory = 0;
	-- Obtener Rol del usuario
	set @roleid = (select case when count(roleid) > 0 THEN roleid ELSE 0 END as roleid  from users where userid = p_userId);
    set @onTime = NULL;
    -- Obtener ElapsedTime entre el registro actual y el último insertado en TicketsHistory
    set @elapsedTime = (
		select
		case when datediff(currentDate,now()) = 0 then
		TIME_TO_SEC(TIMEDIFF(NOW(),currentDate)) else
		TIME_TO_SEC(TIMEDIFF(currentDate,NOW())) end  segundos
		from TicketsHistory 
		where ticketid= p_ticketId        
		ORDER BY ticketshistoryId desc
		LIMIT 1);
	
    IF p_statusId = 9 THEN
			set @onTime = (
            SELECT CASE WHEN sum(elapsedTime)/3600 > em.atentionTime THEN 0 ELSE 1 END OnTime FROM tickets t
			INNER JOIN equipmentModels em on (t.equipmentModelId = em.equipmentModelId)
			INNER JOIN TicketsHistory th on (t.ticketId = th.ticketId)
			where t.ticketId = p_ticketId);
	END IF;
    
    IF @roleid = 5 THEN
		UPDATE Tickets 
		SET statusId = p_statusID, modificationDate = NOW(), onTime = @onTime, priorityId = p_priorityId
		WHERE ticketId = p_ticketId;
    ELSE
		UPDATE Tickets 
		SET statusId = p_statusID, modificationDate = NOW(), onTime = @onTime
		WHERE ticketId = p_ticketId;    
    END IF;
    
	IF @roleid = 5 THEN		
		-- INSERT REGISTRO ROl MONITORISTA        
		INSERT INTO  TicketsHistory
        VALUES (0, p_ticketId, p_comment, NOW(), @elapsedTime, p_technicalId, p_statusId, p_userId);                
    ELSE IF @roleid = 3 THEN
		-- INSERT REGISTRO ROl TÉCNICO
        IF p_statusId = 6 or p_statusId = 7 THEN
			-- SE AGREGA ELAPSEDTIME SOLO CUANDO LOS PAUSA Y CUANDO LO PONE EN REVISIÓN
			INSERT INTO  TicketsHistory
			VALUES (0, p_ticketId, p_comment, NOW(), @elapsedTime, p_userId, p_statusId, p_userId);                    
		ELSE IF p_statusId = 5 THEN
			-- NO SE AGREGA ELAPSEDTIME CUANDO QUITA LA PAUSA
			INSERT INTO  TicketsHistory
			VALUES (0, p_ticketId, p_comment, NOW(), 0, p_userId, p_statusId, p_userId);                    
        END IF;
		END IF;
	ELSE IF @roleid = 4 THEN            
		INSERT INTO TicketsHistory (ticketsHistoryId, ticketId, comment, currentDate, elapsedTime, technicalID, statusId, userId)
		SELECT 0,ticketId,p_comment,NOW(),(select sum(elapsedTime) from TicketsHistory where ticketid= p_ticketId)
        ,technicalID,p_statusId,p_userId FROM TicketsHistory
		where ticketid= p_ticketId
		ORDER BY ticketshistoryId desc
		LIMIT 1;        
	ELSE IF @roleid = 2 THEN
		INSERT INTO TicketsHistory (ticketsHistoryId, ticketId, comment, currentDate, elapsedTime, technicalID, statusId, userId)
		SELECT 0,ticketId,p_comment,NOW(),0,technicalID,p_statusId,p_userId FROM TicketsHistory
		where ticketid= p_ticketId
		ORDER BY ticketshistoryId desc
		LIMIT 1;          
	END IF;
    END IF;
    END IF;
    END IF;
    
    set @tiketHistory = (select ticketsHistoryId from ticketshistory where ticketId = p_ticketId order by ticketsHistoryId desc limit 1);
    
    IF(@tiketHistory > 0) THEN
		set p_ticketHistoyID = @tiketHistory;
		SET p_result = 1;
        
        IF @roleid = 1 THEN
			SET p_message = '¡ticketsHistoy acutalizado!';
        ELSE IF @roleid = 2  THEN
			SET p_message = '¡Ticket Rechazado!';
		ELSE IF @roleid = 3  THEN
			SET p_message = '¡ticketsHistoy acutalizado!';
		ELSE IF @roleid = 5  THEN
			SET p_message = '¡Ticket asignado correctamente!';
		ELSE IF @roleid = 5  THEN
			SET p_message = '¡ticketsHistoy acutalizado!';
        END IF;
        END IF;
        END IF;
        END IF;
        END IF;
        
    ELSE
		set p_ticketHistoyID = @tiketHistory;
		SET p_result = 0;
        -- SET p_message = '¡No se pudo actualizar ticketsHistory!';
        SET p_message = CONCAT('p_userId: ' , p_userId, 'p_ticketId: ' , p_ticketId, 'p_statusId: ', p_statusId, 'p_comment: ' , p_comment, 'p_technicalId: ', p_technicalId, 'p_priorityId: ', p_priorityId);		
        
        
        
		
    END IF;
END;

