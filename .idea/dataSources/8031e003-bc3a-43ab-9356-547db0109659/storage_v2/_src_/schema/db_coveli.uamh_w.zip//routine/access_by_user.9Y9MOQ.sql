create
    definer = anam@`192.168.%` procedure access_by_user(IN userId int, IN nextPath varchar(64))
BEGIN
	SELECT CASE WHEN (select v.path from viewsbyrole v where v.roleid = r.roleid and v.path = nextPath) IS NULL THEN false ELSE true END result FROM users u
    LEFT JOIN roles r ON u.roleid = r.roleid
    WHERE u.userid = userId ;
END;

