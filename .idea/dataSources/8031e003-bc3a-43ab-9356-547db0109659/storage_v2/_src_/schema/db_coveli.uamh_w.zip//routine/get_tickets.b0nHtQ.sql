create
    definer = anam@`192.168.%` procedure get_tickets()
BEGIN
select distinct t.ticketId, t.categoryId, c.category, t.equipmentLocationId, eql.equipmentLocation,  
t.equipmentModelId, eqm.equipmentModel, t.equipmentSerialId, eqs.equipmentSerial,
DATE_FORMAT(t.modificationDate, "%M %d, %Y %r") modificationDate, t.onTime, DATE_FORMAT(t.openDate, "%M %d, %Y %r") openDate,t.priorityId, p.priority, t.situation,t.statusid,s.status 
from tickets t
inner join categories c ON (t.categoryId = c.categoryId)
inner join equipmentlocations eql on (t.equipmentLocationId = eql.equipmentLocationId)
inner join equipmentmodels eqm on (t.equipmentModelId = eqm.equipmentModelId)
inner join equipmentserials eqs on (t.equipmentSerialId = eqs.equipmentSerialId)
inner join status s on (t.statusId = s.statusId)
inner join priorities p on (t.priorityId = p.priorityId or t.priorityId is null)
order by t.ticketId;
END;

